//
//  Credentials.swift
//  Randomizer
//
//  Created by Sharell Scott on 9/20/23.
//

import Foundation
import GoogleAPIClientForREST

class Credentials {
    var stored_service = GTLRYouTubeService()
}
