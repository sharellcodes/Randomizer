//
//  testingViewController.swift
//  Randomizer
//
//  Created by Sharell Scott on 9/8/23.
//

import UIKit

class testingViewController: UIViewController {
    
    
    @IBOutlet weak var changingLabel: UILabel!
    
    let theLabels: [String] = [
        "Morning Special श्री कृष्ण जी के सुन्दर सुन्दर भजन को सुनने से कृष्ण जी की कृपा सदैव आप पर बनी रहती",
        "【ストーリー】第2章1話「私の記憶」【アニメ】【漫画/マンガ動画】",
        "Single Unders | Freeletics 2 Minutes to Master",
        "AA", "AAAAAAAAABBBBBBBBCCCCCCCDDDDDDDDEEEEEEEEFFFFFGGGGGGGHHHHHHH"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        changingLabel.text = theLabels.randomElement()
        changingLabel.sizeToFit()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func changingTest(_ sender: Any) {
        changingLabel.text = theLabels.randomElement()
        // changingLabel.sizeToFit()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
